import "./App.css";
import Header from "./My_Components/Header";
import { Footer } from "./My_Components/Footer";
import { Todos } from "./My_Components/Todos";

function App() {
  let todos = [
    {
      sno: 1,
      title: "Go to market",
      desc: "you need to go to market to get this job done",
    },
    {
      sno: 2,
      title: "Go to mall",
      desc: "you need to go to market to get this job done",
    },
    {
      sno: 3,
      title: "Go to mark",
      desc: "you need to go to market to get this job done",
    },
  ];
  return (
    <>
      <Header title="My todo list" />
      <Todos todos={Todos} />
      <Footer />
    </>
  );
}

export default App;
