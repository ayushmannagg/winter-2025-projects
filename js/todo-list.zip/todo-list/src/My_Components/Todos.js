import React from 'react'
import {Todo_item} from "./Todo_item"

export const Todos = (props) => {
  return (
    <div className="container">
    <h3>Todos list</h3>
    <Todo_item todo ={props.todos[0]}/>
    </div>
  )
}
