import React from "react";

export const Todo_item = ({ todo }) => {
  return (
    <div>
      <h3>{todo.title}</h3>
      <p>{todo.desc}</p>
    </div>
  );
};
